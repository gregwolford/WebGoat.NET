using System;
using System.Web;
using System.Web.UI;

namespace OWASP.WebGoat.NET
{
	public partial class ChangePassword : System.Web.UI.Page
	{
	}
}

