using System;
using System.Web;
using System.Web.UI;

namespace OWASP.WebGoat.NET
{
	public partial class ForgotPassword : System.Web.UI.Page
	{
	
	}
}

